using UnityEngine;
using UnityEngine.SceneManagement;

public class GameBootstrap : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void CreateGame()
    {
        if (FindObjectOfType<GameBootstrap>() != null) return;
        new GameObject("ROBO_ADVENTURE_BOOTSTRAP").AddComponent<GameBootstrap>();
    }

    void Start()
    {
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        BuildMenu();
    }

    void BuildMenu()
    {
        RenderSettings.ambientLight = new Color(0.55f, 0.62f, 0.55f);
        var light = new GameObject("Sun").AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.15f;
        light.transform.rotation = Quaternion.Euler(48, -35, 0);
        Camera.main?.gameObject.SetActive(false);
        var camObj = new GameObject("MenuCamera");
        var cam = camObj.AddComponent<Camera>();
        camObj.transform.position = new Vector3(0, 5, -10);
        camObj.transform.rotation = Quaternion.Euler(18, 0, 0);
        cam.clearFlags = CameraClearFlags.Skybox;
    }

    void OnGUI()
    {
        if (GameState.Started) return;
        GUI.skin.button.fontSize = Mathf.Max(18, Screen.width / 32);
        GUI.skin.label.fontSize = Mathf.Max(20, Screen.width / 28);
        float w = Mathf.Min(520, Screen.width - 40);
        float x = (Screen.width - w) / 2;
        GUI.Label(new Rect(x, Screen.height * .22f, w, 60), "ROBO ADVENTURE 3D");
        GUI.Label(new Rect(x, Screen.height * .32f, w, 45), GameState.Russian ? "ПРИКЛЮЧЕНИЕ НАЧИНАЕТСЯ" : "THE ADVENTURE BEGINS");
        if (GUI.Button(new Rect(x, Screen.height * .48f, w, 58), GameState.Russian ? "ИГРАТЬ" : "PLAY"))
        {
            GameState.Started = true;
            BuildLevel();
        }
        if (GUI.Button(new Rect(x, Screen.height * .60f, w, 48), GameState.Russian ? "ЯЗЫК: РУССКИЙ / ENGLISH" : "LANGUAGE: ENGLISH / РУССКИЙ"))
            GameState.Russian = !GameState.Russian;
        GUI.Label(new Rect(x, Screen.height * .78f, w, 40), "VERDANT • PROTOTYPE 01");
    }

    void BuildLevel()
    {
        var menuCam = GameObject.Find("MenuCamera");
        if (menuCam) Destroy(menuCam);
        var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "Verdant_Ground";
        floor.transform.localScale = new Vector3(12, 1, 12);
        floor.GetComponent<Renderer>().material.color = new Color(.16f, .34f, .18f);

        for (int i = 0; i < 34; i++)
        {
            float a = i * 2.399f;
            float r = 7f + (i % 5) * 1.1f;
            Vector3 p = new Vector3(Mathf.Cos(a) * r, 0, Mathf.Sin(a) * r);
            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            trunk.name = "Jungle_Tree_Trunk";
            trunk.transform.position = p + Vector3.up * 1.3f;
            trunk.transform.localScale = new Vector3(.35f, 1.3f, .35f);
            trunk.GetComponent<Renderer>().material.color = new Color(.25f, .16f, .08f);
            var crown = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            crown.name = "Jungle_Canopy";
            crown.transform.position = p + Vector3.up * 3.2f;
            crown.transform.localScale = new Vector3(2.2f, 2.0f, 2.2f);
            crown.GetComponent<Renderer>().material.color = new Color(.08f, .35f, .12f);
        }

        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "ROBO-X";
        player.transform.position = new Vector3(0, 1.2f, 0);
        player.GetComponent<Renderer>().material.color = new Color(.2f, .65f, .9f);
        var controller = player.AddComponent<CharacterController>();
        controller.height = 2f; controller.radius = .45f;
        player.AddComponent<RoboController>();

        var camObj = new GameObject("ThirdPersonCamera");
        var camera = camObj.AddComponent<Camera>();
        camera.tag = "MainCamera";
        cameraObjFollow follow = camObj.AddComponent<cameraObjFollow>();
        follow.target = player.transform;

        for (int i = 0; i < 6; i++)
        {
            var enemy = GameObject.CreatePrimitive(PrimitiveType.Cube);
            enemy.name = "Jungle_Scout";
            enemy.transform.position = new Vector3((i - 2.5f) * 3f, .7f, 9f + (i % 2) * 3f);
            enemy.transform.localScale = new Vector3(1.1f, 1.4f, 1.1f);
            enemy.GetComponent<Renderer>().material.color = new Color(.65f, .18f, .12f);
            enemy.AddComponent<SimpleEnemy>();
        }

        var hud = new GameObject("MobileHUD");
        hud.AddComponent<MobileHUD>();
    }
}

public static class GameState
{
    public static bool Started = false;
    public static bool Russian = true;
    public static int Lives = 5;
    public static int Energy = 0;
}
