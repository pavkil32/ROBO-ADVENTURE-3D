using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class RoboController : MonoBehaviour
{
    public float moveSpeed = 5.5f;
    public float jumpHeight = 1.5f;
    public float gravity = -18f;
    CharacterController cc;
    Vector3 velocity;
    public static float HorizontalInput;
    public static float VerticalInput;
    public static bool JumpPressed;

    void Awake() { cc = GetComponent<CharacterController>(); }

    void Update()
    {
        float h = HorizontalInput + Input.GetAxisRaw("Horizontal");
        float v = VerticalInput + Input.GetAxisRaw("Vertical");
        Vector3 move = new Vector3(h, 0, v);
        if (move.sqrMagnitude > 1) move.Normalize();
        if (move.sqrMagnitude > .01f)
        {
            transform.forward = Vector3.Slerp(transform.forward, move, 12f * Time.deltaTime);
            cc.Move(move * moveSpeed * Time.deltaTime);
        }
        if (cc.isGrounded && velocity.y < 0) velocity.y = -2f;
        if ((JumpPressed || Input.GetButtonDown("Jump")) && cc.isGrounded)
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        JumpPressed = false;
        velocity.y += gravity * Time.deltaTime;
        cc.Move(velocity * Time.deltaTime);
    }

    public void TakeDamage()
    {
        GameState.Lives = Mathf.Max(0, GameState.Lives - 1);
        if (GameState.Lives == 0) transform.position = new Vector3(0, 1.2f, 0);
    }
}
