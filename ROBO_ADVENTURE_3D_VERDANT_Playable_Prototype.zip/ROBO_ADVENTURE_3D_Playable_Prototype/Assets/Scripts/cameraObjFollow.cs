using UnityEngine;
public class cameraObjFollow : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0, 4.2f, -6.5f);
    void LateUpdate()
    {
        if (!target) return;
        transform.position = Vector3.Lerp(transform.position, target.position + target.TransformDirection(offset), 8f * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 1.1f);
    }
}
