using UnityEngine;
public class SimpleEnemy : MonoBehaviour
{
    Transform player;
    float hitCooldown;
    void Start() { var p = GameObject.Find("ROBO-X"); if (p) player = p.transform; }
    void Update()
    {
        if (!player) return;
        Vector3 d = player.position - transform.position; d.y = 0;
        if (d.magnitude < 9f)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(d), 3f * Time.deltaTime);
            if (d.magnitude > 1.8f) transform.position += d.normalized * 1.4f * Time.deltaTime;
            if (d.magnitude < 1.5f && Time.time > hitCooldown)
            {
                player.GetComponent<RoboController>()?.TakeDamage();
                hitCooldown = Time.time + 2.5f;
            }
        }
    }
}
