using UnityEngine;
public class MobileHUD : MonoBehaviour
{
    void OnGUI()
    {
        GUI.skin.button.fontSize = Mathf.Max(16, Screen.width / 42);
        GUI.skin.label.fontSize = Mathf.Max(16, Screen.width / 42);
        GUI.Label(new Rect(16, 12, 360, 36), (GameState.Russian ? "ЖИЗНИ: " : "LIVES: ") + GameState.Lives + "   VERDANT");
        float s = Mathf.Clamp(Screen.width * .14f, 64, 100);
        Rect left = new Rect(18, Screen.height - s * 1.55f, s, s);
        Rect right = new Rect(18 + s * 1.1f, Screen.height - s * 1.55f, s, s);
        Rect up = new Rect(18 + s * 1.1f, Screen.height - s * 2.65f, s, s);
        Rect down = new Rect(18 + s * 1.1f, Screen.height - s * .45f, s, s);
        RoboController.HorizontalInput = 0; RoboController.VerticalInput = 0;
        if (GUI.RepeatButton(left, "◀")) RoboController.HorizontalInput = -1;
        if (GUI.RepeatButton(right, "▶")) RoboController.HorizontalInput = 1;
        if (GUI.RepeatButton(up, "▲")) RoboController.VerticalInput = 1;
        if (GUI.RepeatButton(down, "▼")) RoboController.VerticalInput = -1;
        if (GUI.Button(new Rect(Screen.width - s * 1.25f, Screen.height - s * 1.5f, s, s), GameState.Russian ? "ПРЫЖОК" : "JUMP"))
            RoboController.JumpPressed = true;
        if (GUI.Button(new Rect(Screen.width - s * 1.25f, Screen.height - s * 2.65f, s, s), GameState.Russian ? "АТАКА" : "ATTACK"))
        {
            var enemies = FindObjectsOfType<SimpleEnemy>();
            foreach (var e in enemies)
                if (Vector3.Distance(e.transform.position, GameObject.Find("ROBO-X").transform.position) < 3.5f)
                    Destroy(e.gameObject);
        }
    }
}
