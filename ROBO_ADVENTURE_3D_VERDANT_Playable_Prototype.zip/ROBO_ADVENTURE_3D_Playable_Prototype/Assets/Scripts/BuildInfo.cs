public static class BuildInfo
{
    public const string GameTitle = "ROBO ADVENTURE 3D";
    public const string TargetPlatform = "Android";
    public const string Languages = "Russian, English";
    public const string FirstPlayableWorld = "VERDANT";
    public const string PackageId = "com.roboadventure3d.game";
}
