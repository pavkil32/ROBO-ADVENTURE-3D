using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BuildScript
{
    public static void PerformAndroidBuild()
    {
        const string outputDirectory = "build/Android";
        Directory.CreateDirectory(outputDirectory);

        string[] scenes = GetEnabledScenes();
        if (scenes.Length == 0)
            throw new System.Exception("No enabled scenes found in Build Settings.");

        EditorUserBuildSettings.SwitchActiveBuildTarget(
            BuildTargetGroup.Android, BuildTarget.Android);

        PlayerSettings.productName = "ROBO ADVENTURE 3D";
        PlayerSettings.companyName = "ROBO ADVENTURE";
        PlayerSettings.SetApplicationIdentifier(
            BuildTargetGroup.Android, "com.roboadventure3d.game");
        PlayerSettings.Android.targetArchitectures =
            AndroidArchitecture.ARM64;
        PlayerSettings.defaultInterfaceOrientation =
            UIOrientation.LandscapeLeft;

        string outputPath = Path.Combine(
            outputDirectory, "ROBO-ADVENTURE-3D.apk");

        BuildPlayerOptions options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = outputPath,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new System.Exception(
                "Android build failed: " + report.summary.result);
        Debug.Log("APK created: " + outputPath);
    }

    private static string[] GetEnabledScenes()
    {
        var scenes = EditorBuildSettings.scenes;
        var enabled = new System.Collections.Generic.List<string>();
        foreach (var scene in scenes)
            if (scene.enabled) enabled.Add(scene.path);
        return enabled.ToArray();
    }
}
